count=0
with open("Sample.txt",'rt+')as f:
    for line in f:
        word=line.split()
        count+=len(word)
f.close()
print("Total No of Words are:",count)
