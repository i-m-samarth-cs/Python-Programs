count=0
with open("Sample.txt",'rt+')as f:
    for line in f:
        word=line.split()
        count+=1
f.close()
print("Total No of Lines in File:",count)
