with open("Sample.txt",'rt')as inf:
    line=inf.readline()
    words=line.split()
    print(words)
