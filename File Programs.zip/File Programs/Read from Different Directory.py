#2.In Different Directory
file=open(r"C:\Users\Admin\Desktop\6th Semester Notes\Android\Control Flow Steps  Work in Android.txt")
print(file.read())
