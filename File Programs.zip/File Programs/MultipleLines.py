fo=open("Sample.txt","rt+")
lines=["welcome to Python \n","It's Fun \n","Python is Easy"]
fo.writelines(lines)
fo.close()
