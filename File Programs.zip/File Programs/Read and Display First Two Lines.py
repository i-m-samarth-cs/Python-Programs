inf=open(r"C:\Users\Admin\Desktop\Python Programs\File Programs\Sample.txt","rt")
print(inf.readline())
print(inf.readline())
inf.close()
