print("Enter'x' for exit")
filename=input("Enter File Name")
if filename=='x':
    exit()
else:
    c=open(filename,'w')
print("\n The File",filename," Created Successfully")
