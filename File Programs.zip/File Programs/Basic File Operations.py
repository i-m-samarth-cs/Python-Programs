inf=open(r"C:\Users\Admin\Desktop\Python Programs\File Programs\Sample.txt",'r')
inf.read()
print(inf.read())
inf.close()
