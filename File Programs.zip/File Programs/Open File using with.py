with open(r"C:\Users\Admin\Desktop\Python Programs\File Programs\Sample.txt",'rt') as inf:
    for line in inf:
        print(line)
    inf.close()
    
