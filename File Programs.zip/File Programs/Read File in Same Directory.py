#1)In the Same Directory
file=open("Sample.txt")
print(file.read())

