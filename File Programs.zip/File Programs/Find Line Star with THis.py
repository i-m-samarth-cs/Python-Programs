f=open("Sample.txt")
i=0
for line in f:
    line=line.rstrip()
    if line.find("This")==-1:
        continue
    print(line)
