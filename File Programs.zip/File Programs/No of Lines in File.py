print("How many lines to write")
n=int(input())
out=open("Sample.txt",'rt+')
for i in range(n):
    print("Enter Line")
    line=input()
    out.write("\n"+line)
out.close()

print("Contents of File are")

inf=open("Sample.txt",'rt+')
print(inf.read())
inf.close()
