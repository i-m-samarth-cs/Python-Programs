inf=open(r"C:\Users\Admin\Desktop\Python Programs\File Programs\Sample.txt",'r')
print(inf.read())

