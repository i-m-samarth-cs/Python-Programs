import os
print(os.getcwd())
os.chdir("E:\\Bills")
print("Now at:",os.getcwd())
print("It Contains:")
print(os.listdir())
os.mkdir("Python")
print(os.listdir())

os.rename("Python","PY")
print(os.listdir())

os.remove("PY")
print(os.listdir())

print("is E:\\Timepass exists?",os.path.exists("E:\\Timepass"))
print("Is E:\\Bills a directory?:",os.path.isdir("E:\\Bills"))
                                        
