inf=open(r"C:\Users\Admin\Desktop\Python Programs\File Programs\Sample.txt",'rt')
for line in inf:
    print("\n",line)
inf.close()
