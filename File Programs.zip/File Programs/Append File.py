file=open("Sample.txt",'a')  #append mode
file.write("\n Add This Line")
file.close()

with open('Sample.txt','w') as f:
    data='''Do not be pushed around to older data'''
    f.write(data)
fo=open("Sample.txt","r")
print(fo.read())
