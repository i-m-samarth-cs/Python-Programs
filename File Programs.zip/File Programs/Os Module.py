import os
os.getcwd()
print("Contents of Present Directory \n",os.listdir())
print(os.path.isfile("Sample.txt"))
print(os.path.isdir("Sample.txt"))
