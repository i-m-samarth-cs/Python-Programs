import os
f=open("Sample.txt")        #read only
f=open("Sample.txt",'w')    #write mode
f=open("Sample.txt",'rb+')    #read and write in binary
