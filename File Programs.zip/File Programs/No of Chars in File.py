count=0
with open("Sample.txt",'r') as f:
    for line in f:
        word=line.split()
        count+=len(line)
f.close()
print("Total No of Chars are:",count)

