file=input("enter file name")
l=input("Enter Letter to Search:")
k=0
with open(file,'r')as f:
    for line in f:
        words=line.split()
        for i in words:
            for letter in i:
                if(letter==l):
                    k=k+1
print("Occurances of Letter:",k)
