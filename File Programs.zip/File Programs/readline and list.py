inf=open(r"C:\Users\Admin\Desktop\Python Programs\File Programs\Sample.txt",'rt')
print(inf.readline())
inf.close()

inf1=open("Sample.txt",'rt')
print(list(inf1))
inf.close()
