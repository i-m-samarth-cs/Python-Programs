with open("Sample.txt",'rt+') as f:
    count=0
    for line in f:
        word=line.split()
        for letter in word:
            if(!letter.isspace):
                count=count+1
print("Total No of Blank Spaces:",count)
