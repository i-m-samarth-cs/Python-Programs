inf=open("Sample.txt",'rt+')
vowels=set("aeiouAEIOU")
cons=set("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ")
count_v=0
count_c=0
for c in inf.read():
    if c in vowels:
        count_v+=1
    elif c in cons:
        count_c+=1
print("No of Vowels:",count_v)
print("No of Consonants:",count_c)
inf.close()
