f=open("Sample.txt","rt+")
print(f.read())
f.write("First Line")
f.write("\n Second Line")
s=f.write("\n Third Line")
print("No of char Written",s)
print(f.read())

fruits=["Orange \n","Banana \n","Apple \n"]
f.writelines(fruits)
f.close()
