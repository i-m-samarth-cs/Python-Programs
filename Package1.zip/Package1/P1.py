def m1():
    print("First Number")
    
