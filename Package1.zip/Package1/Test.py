import P1,P2
P1.m1()
P2.m2()
