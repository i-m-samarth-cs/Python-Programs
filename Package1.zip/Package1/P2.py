def m2():
    print("Second Number")
    
