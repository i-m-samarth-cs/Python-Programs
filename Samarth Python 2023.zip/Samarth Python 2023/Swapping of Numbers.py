a=int(input("Enter Number 1:"))
b=int(input("Enter Number 2:"))

c=a
a=b
b=c

print("A=",a)
print("B=",b)
