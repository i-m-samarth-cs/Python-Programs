a=int(input("Enter Marks 1:"))
b=int(input("Enter Marks 2:"))
c=int(input("Enter Marks 3:"))
d=int(input("Enter Marks 4:"))
e=int(input("Enter Marks 5:"))

f=a+b+c+d+e

if(f>150):
    print("Pass")
else:
    print("Fail")
