import math
n=5
fact=1
for n in range(1,6):
    fact=fact*n
    n-=1
print(fact)

print(math.factorial(5))

