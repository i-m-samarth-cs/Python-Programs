a=int(input("Enter Year:"))

if(a%4==0):
    print(a," is Leap Year")
else:
    print(a," is not Leap Year")
