
sum=0
for i in range(1,10):
    sum=sum+i
print("Sum =",sum)
