a=int(input("Enter Number 1:"))
b=int(input("Enter Number 2:"))

c=a>b or b>a;
print("Logical OR",c);

c=a>b and b>a;
print("Logical AND",c);

c=not(a<b);
print("Logical NOT",c);

