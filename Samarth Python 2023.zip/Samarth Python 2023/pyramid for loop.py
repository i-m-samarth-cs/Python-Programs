list1=[1,2,3,4]
for i in list1:
    for j in range(1,i+1):
        print("*",end="")
    print()
