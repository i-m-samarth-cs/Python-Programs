print("MSBTE")
