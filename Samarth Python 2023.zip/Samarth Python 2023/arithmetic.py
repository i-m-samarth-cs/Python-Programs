a=int(input("Enter Number 1:"))
b=int(input("Enter Number 2:"))

c=a+b;
print("Addition =",c)

c=a-b;
print("Subtraction =",c)

c=a*b;
print("Multiplication =",c)

c=a/b;
print("Division =",c)

