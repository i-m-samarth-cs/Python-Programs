a=int(input("Enter Number 1:"))
b=int(input("Enter Number 2:"))

if(a>b):
    if(a==10):
        print("No is equals to 10")
    else:
        print("No is not equals to 10")
else:
    print("B is Largest")
