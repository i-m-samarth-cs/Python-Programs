a=int(input("Enter Side of Square:"))
b=a*a
print("Area of Square",b,"sq.m")

c=4*a
print("Perimeter of Square",c,"sq.m")
