a=int(input("Enter Number:"))

if(a>0):
    print("No is Positive")
elif(a<0):
    print("No is Negative")
else:
    print("No is Zero")
