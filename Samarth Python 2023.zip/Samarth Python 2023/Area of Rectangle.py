a=int(input("Enter Length of Rectangle:"))
b=int(input("Enter Breadth of Rectangle:"))\

ar=a*b
print("Area of Rectangle:",ar,"sq.m")
