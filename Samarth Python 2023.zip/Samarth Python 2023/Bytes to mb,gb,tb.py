a=int(input("Enter No of Bits:"))

b=a/(8*1024*1024)
print("Megabytes=",b)

c=a/(8*1024*1024*1024)
print("Gigabytes=",c)

d=a/(8*1024*1024*1024*1024)
print("Terabytes=",d)
