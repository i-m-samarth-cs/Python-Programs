n=141
rev=0
rem=0
num=n
while(n!=0):
    rem=n%10
    rev=(rev*10)+rem
    n=int(n/10)
if(num==rev):
    print("Number is Palindrome")
else:
    print("Number is not Palindrome")
