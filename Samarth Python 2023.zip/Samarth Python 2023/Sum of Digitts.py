num=123
sum=0
i=0
while(num!=0):
    rem=num%10
    sum=int(sum+rem)
    num=int(num/10)
    
print(sum)
