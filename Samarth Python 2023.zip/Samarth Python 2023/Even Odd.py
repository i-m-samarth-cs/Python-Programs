a=int(input("Enter Number 1:"))

if(a%2==0):
    print("No is Even")
else:
    print("No is Odd")
    
