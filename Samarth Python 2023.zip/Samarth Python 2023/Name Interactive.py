a=input("Enter your Name:");
print("************",a,"*************")
