a=int(input("Enter Number 1:"))
b=int(input("Enter Number 2:"))

c=a&b
print("Bitwise And:",c)

c=a|b
print("Bitwise OR:",c)

c=a^b
print("Bitwise XOR:",c)

c=a>>b # We can use numbers in place of variable
print("Bitwise Left Shifr:",c)

c=a<<b # We can use numbers in place of variable
print("Bitwise Rigth Shift:",c)
