a=int(input("Enter Number 1:"))
b=int(input("Enter Number 2:"))

if(a>b):
    print("A is Largest")
else:
    print("B is Largest")
