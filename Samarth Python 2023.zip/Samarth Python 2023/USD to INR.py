a=int(input("Enter Amount in Dollar:"))
b=a*80.00

print("Amount in INR",b," Rs");
