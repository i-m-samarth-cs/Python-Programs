

## we can import math library and use math.sqrt() function
a=int(input("Enter Number 1:"))
b=a**0.5
print("Square Root of",a,"is=",b)
