import math

a=float(input("Enter Number 1:"))

b=math.floor(a)

print("Absolute Floor Value:",b)

b=math.ceil(a)

print("Absolute Ceil Value:",b)

