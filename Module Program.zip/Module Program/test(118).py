#test.py

import mymodule

a=mymodule.person1['name']
print(a)
