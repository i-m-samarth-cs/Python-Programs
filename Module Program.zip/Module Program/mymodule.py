#MYMODULE.py

person1={
    'name':"Brad",'subject':'Python','Marks':70
}
