#SWAP
def swap(a,b):
    temp=a
    a=b
    b=temp
    print("After Swapping")
    print(a)
    print(b)
    
