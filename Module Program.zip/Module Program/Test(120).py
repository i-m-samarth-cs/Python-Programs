import Fibseries
Fibseries.fib(10)
