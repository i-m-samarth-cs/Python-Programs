#Test
import Swap as s
s.swap(10,20)
