#TEST#
import ArithmeticModule as pl
print("Addition=",pl.add(10,20))
print("Subtraction=",pl.sub(10,20))
