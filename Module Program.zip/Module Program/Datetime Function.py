import datetime as time

x=time.datetime.now()
print(x)

